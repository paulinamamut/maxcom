﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Maxcom.Areas.AtencionAClientes.Controllers
{
    public class LocalizadorController : Controller
    {
        //
        // GET: /AtencionAClientes/Localizador/

        public ActionResult Index()
        {
            return View();
        }

    }
}
