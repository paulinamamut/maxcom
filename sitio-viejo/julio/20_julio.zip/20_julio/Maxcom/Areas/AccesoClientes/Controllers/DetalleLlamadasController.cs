﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Maxcom.Areas.AccesoClientes.Controllers
{
    public class DetalleLlamadasController : Controller
    {
        //
        // GET: /AccesoClientes/DetalleLlamadas/

        public ActionResult Index()
        {
            return View();
        }

    }
}
