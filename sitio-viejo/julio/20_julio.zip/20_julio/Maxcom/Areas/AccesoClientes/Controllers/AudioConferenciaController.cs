﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Maxcom.Areas.AccesoClientes.Controllers
{
    public class AudioConferenciaController : Controller
    {
        //
        // GET: /AccesoClientes/AudioConferencia/

        public ActionResult Index()
        {
            return View();
        }

    }
}
