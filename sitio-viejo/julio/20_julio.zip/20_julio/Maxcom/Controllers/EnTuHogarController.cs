﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Maxcom.Controllers
{
    public class EnTuHogarController : Controller
    {
        //
        // GET: /EnTuHogar/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MaxConexion()
        {
            return View();
        }

        public ActionResult MaxDiversion()
        {
            return View();
        }

        public ActionResult MaxMovil()
        {
            return View();
        }
    }
}
